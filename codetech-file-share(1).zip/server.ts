import express from 'express';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

// Set up storage directory
const UPLOADS_DIR = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const DB_FILE = path.join(UPLOADS_DIR, 'files_meta.json');

interface FileRecord {
  id: string;
  originalName: string;
  filename: string;
  size: number;
  mimeType: string;
  uploadDate: string;
  storageEngine: 'codetech_server' | 'gofile' | 'litterbox' | 'tmpfiles';
  externalUrl?: string;
  downloadCount: number;
  aiSummary?: string;
}

function loadRecords(): Record<string, FileRecord> {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Failed to load files metadata:', err);
  }
  return {};
}

function saveRecords(records: Record<string, FileRecord>) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(records, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to save files metadata:', err);
  }
}

// Multer disk storage - no hard file size cap (streams directly to disk)
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const safeName = file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
    cb(null, `${uniqueSuffix}-${safeName}`);
  },
});

const upload = multer({
  storage,
  limits: {
    // 5GB per file default ceiling for server uploads
    fileSize: 5 * 1024 * 1024 * 1024,
  },
});

app.use(express.json());

// Enable CORS and handle preflight requests for all methods (GET, POST, PUT, DELETE, OPTIONS)
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    return res.status(204).end();
  }
  next();
});

// API Routes
// Health Check
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
  });
});

// List recent files
app.get('/api/files/recent', (_req, res) => {
  const records = loadRecords();
  const list = Object.values(records).sort(
    (a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime()
  );
  res.json({ success: true, files: list.slice(0, 30) });
});

// Get file metadata by ID
app.get('/api/files/:id/meta', (req, res) => {
  const records = loadRecords();
  const file = records[req.params.id];
  if (!file) {
    return res.status(404).json({ success: false, message: 'File not found' });
  }
  return res.json({ success: true, file });
});

// Direct Download endpoint
app.get('/api/download/:id', (req, res) => {
  const records = loadRecords();
  const file = records[req.params.id];
  if (!file) {
    return res.status(404).send('File not found or has been removed');
  }

  // If stored externally, redirect to external URL
  if (file.externalUrl) {
    file.downloadCount = (file.downloadCount || 0) + 1;
    saveRecords(records);
    return res.redirect(file.externalUrl);
  }

  const filePath = path.join(UPLOADS_DIR, file.filename);
  if (!fs.existsSync(filePath)) {
    return res.status(404).send('File missing on disk');
  }

  file.downloadCount = (file.downloadCount || 0) + 1;
  saveRecords(records);

  res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(file.originalName)}"`);
  res.setHeader('Content-Type', file.mimeType || 'application/octet-stream');
  res.setHeader('Content-Length', file.size.toString());

  const readStream = fs.createReadStream(filePath);
  readStream.pipe(res);
});

// Preview endpoint (inline view for images, audio, video, text)
app.get('/api/files/:id/preview', (req, res) => {
  const records = loadRecords();
  const file = records[req.params.id];
  if (!file) {
    return res.status(404).send('File not found');
  }

  if (file.externalUrl) {
    return res.redirect(file.externalUrl);
  }

  const filePath = path.join(UPLOADS_DIR, file.filename);
  if (!fs.existsSync(filePath)) {
    return res.status(404).send('File missing');
  }

  res.setHeader('Content-Type', file.mimeType || 'application/octet-stream');
  res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(file.originalName)}"`);
  fs.createReadStream(filePath).pipe(res);
});

// Delete file endpoint (supports both DELETE and POST for maximum browser/proxy compatibility)
const handleFileDeletion = (req: express.Request, res: express.Response) => {
  try {
    const fileId = req.params.id;
    const records = loadRecords();
    const file = records[fileId];

    if (file) {
      const filePath = path.join(UPLOADS_DIR, file.filename);
      if (fs.existsSync(filePath)) {
        try {
          fs.unlinkSync(filePath);
        } catch (e) {
          console.error('Error deleting file from disk:', e);
        }
      }
      delete records[fileId];
      saveRecords(records);
    }

    return res.json({ success: true, message: 'File successfully deleted' });
  } catch (err: any) {
    console.error('Error during file deletion:', err);
    return res.status(500).json({ success: false, message: err?.message || 'Delete failed' });
  }
};

app.delete('/api/files/:id', handleFileDeletion);
app.post('/api/files/:id/delete', handleFileDeletion);

// Helper for Gemini AI analysis
async function analyzeFileWithGemini(fileBuffer: Buffer, fileName: string, mimeType: string): Promise<string> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return 'Walang GEMINI_API_KEY na naka-configure para sa AI analysis.';
  }

  const ai = new GoogleGenAI({ apiKey });

  try {
    const isText = mimeType.startsWith('text/') || 
      fileName.endsWith('.txt') || 
      fileName.endsWith('.json') || 
      fileName.endsWith('.js') || 
      fileName.endsWith('.ts') || 
      fileName.endsWith('.html') || 
      fileName.endsWith('.css') || 
      fileName.endsWith('.md') ||
      fileName.endsWith('.py');

    if (isText && fileBuffer.length < 500_000) {
      const textContent = fileBuffer.toString('utf-8', 0, 25_000);
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: `Ikaw ay isang matalinong file analyzer para sa Codetech File Sharing Portal. 
I-analyze ang file na "${fileName}" (${mimeType}) at magbigay ng maikli ngunit malinaw na buod (sa Tagalog/Filipino):
1. Uri ng file at nilalaman
2. Buod ng nakasaad
3. Mahahalagang paalala o tip para sa recipient

Sample content:
${textContent}`
              }
            ]
          }
        ]
      });
      return response.text || 'Walang nabuong buod ang AI.';
    } else if (fileBuffer.length <= 15 * 1024 * 1024 && (mimeType.startsWith('image/') || mimeType === 'application/pdf')) {
      const base64Data = fileBuffer.toString('base64');
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: [
          {
            role: 'user',
            parts: [
              {
                inlineData: {
                  data: base64Data,
                  mimeType: mimeType === 'application/pdf' ? 'application/pdf' : mimeType,
                }
              },
              {
                text: `Suriin at ibuod ang file na "${fileName}". Magbigay ng maikling impormasyon sa Tagalog kung ano ang nakasaad at mga detalye.`
              }
            ]
          }
        ]
      });
      return response.text || 'Walang nabuong buod ang AI.';
    } else {
      // For large binaries / archives
      const sizeMB = (fileBuffer.length / (1024 * 1024)).toFixed(2);
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: `Ang user ay nag-upload ng file na may pangalang "${fileName}", uri "${mimeType}", at laki na ${sizeMB} MB. 
Magbigay ng maikling pagpapaliwanag sa Tagalog kung para saan karaniwang ginagamit ang file extension o format na ito, paano ito buksan, at mga tip para sa recipient.`
              }
            ]
          }
        ]
      });
      return response.text || 'Matagumpay na na-upload ang file.';
    }
  } catch (err: any) {
    console.error('Gemini Analysis Error:', err);
    return `AI Analysis Note: ${err.message || 'Hindi nakumpleto ang pagsusuri dahil sa format o timeout.'}`;
  }
}

// Trigger AI analysis manually
app.post('/api/analyze-ai/:id', async (req, res) => {
  const records = loadRecords();
  const file = records[req.params.id];
  if (!file) {
    return res.status(404).json({ success: false, message: 'File not found' });
  }

  const filePath = path.join(UPLOADS_DIR, file.filename);
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ success: false, message: 'File missing on server' });
  }

  try {
    const buffer = fs.readFileSync(filePath);
    const summary = await analyzeFileWithGemini(buffer, file.originalName, file.mimeType);
    file.aiSummary = summary;
    saveRecords(records);
    return res.json({ success: true, aiSummary: summary });
  } catch (err: any) {
    return res.status(500).json({ success: false, message: err.message });
  }
});

// Cloud Relay Helpers for 100% public, worldwide accessible links
async function uploadToLitterbox(filePath: string, originalName: string, mimeType: string): Promise<string | undefined> {
  try {
    const fileBuffer = fs.readFileSync(filePath);
    const blob = new Blob([fileBuffer], { type: mimeType || 'application/octet-stream' });
    const lbForm = new FormData();
    lbForm.append('reqtype', 'fileupload');
    lbForm.append('time', '72h');
    lbForm.append('fileToUpload', blob, originalName);
    const lbRes = await fetch('https://litterbox.catbox.moe/resources/internals/api.php', {
      method: 'POST',
      body: lbForm,
    });
    const lbText = await lbRes.text();
    if (lbText.startsWith('https://')) {
      return lbText.trim();
    }
  } catch (e) {
    console.warn('Litterbox upload relay error:', e);
  }
  return undefined;
}

async function uploadToGoFile(filePath: string, originalName: string, mimeType: string): Promise<string | undefined> {
  try {
    const serverRes = await fetch('https://api.gofile.io/servers');
    const serverJson: any = await serverRes.json();
    const serverName = serverJson?.data?.servers?.[0]?.name;
    if (serverName) {
      const fileBuffer = fs.readFileSync(filePath);
      const blob = new Blob([fileBuffer], { type: mimeType || 'application/octet-stream' });
      const gfForm = new FormData();
      gfForm.append('file', blob, originalName);
      const gfRes = await fetch(`https://${serverName}.gofile.io/contents/uploadfile`, {
        method: 'POST',
        body: gfForm,
      });
      const gfData: any = await gfRes.json();
      if (gfData?.status === 'ok' && gfData?.data?.downloadPage) {
        return gfData.data.downloadPage;
      }
    }
  } catch (e) {
    console.warn('GoFile upload relay error:', e);
  }
  return undefined;
}

// Primary Upload Route
app.post('/api/upload', upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: 'No file uploaded' });
  }

  const { engine = 'codetech_server', runAi = 'false' } = req.body;
  const file = req.file;
  const fileId = 'cd_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6);

  const baseUrl = process.env.APP_URL && !process.env.APP_URL.includes('MY_APP_URL')
    ? process.env.APP_URL.replace(/\/$/, '')
    : `${req.protocol}://${req.get('host')}`;

  const directShareUrl = `${baseUrl}/download/${fileId}`;
  const directApiDownload = `${baseUrl}/api/download/${fileId}`;

  const record: FileRecord = {
    id: fileId,
    originalName: file.originalname,
    filename: file.filename,
    size: file.size,
    mimeType: file.mimetype,
    uploadDate: new Date().toISOString(),
    storageEngine: engine === 'gofile' ? 'gofile' : engine === 'litterbox' ? 'litterbox' : engine === 'tmpfiles' ? 'tmpfiles' : 'codetech_server',
    downloadCount: 0,
  };

  // Obtain a 100% public, worldwide-accessible download link
  if (engine === 'gofile') {
    record.externalUrl = await uploadToGoFile(file.path, file.originalname, file.mimetype);
  } else if (engine === 'litterbox') {
    record.externalUrl = await uploadToLitterbox(file.path, file.originalname, file.mimetype);
  } else if (engine === 'tmpfiles') {
    try {
      const fileBuffer = fs.readFileSync(file.path);
      const blob = new Blob([fileBuffer], { type: file.mimetype });
      const formData = new FormData();
      formData.append('file', blob, file.originalname);

      const tmpRes = await fetch('https://tmpfiles.org/api/v1/upload', {
        method: 'POST',
        body: formData,
      });
      const tmpData: any = await tmpRes.json();
      if (tmpData?.status === 'success' && tmpData.data?.url) {
        const rawUrl = tmpData.data.url;
        record.externalUrl = rawUrl.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
      }
    } catch (e) {
      console.warn('tmpfiles upload failed, attempting fallback to litterbox:', e);
      record.externalUrl = await uploadToLitterbox(file.path, file.originalname, file.mimetype);
    }
  } else {
    // Codetech Server: Also auto-mirror to public cloud relay so the link works for ANY external recipient
    if (file.size <= 1024 * 1024 * 1024) {
      record.externalUrl = await uploadToLitterbox(file.path, file.originalname, file.mimetype);
    }
    if (!record.externalUrl) {
      record.externalUrl = await uploadToGoFile(file.path, file.originalname, file.mimetype);
    }
  }

  // If AI analysis was requested, execute with a safe 8-second timeout
  if (runAi === 'true' || runAi === true) {
    try {
      const buffer = fs.readFileSync(file.path);
      const aiPromise = analyzeFileWithGemini(buffer, file.originalname, file.mimetype);
      const timeoutPromise = new Promise<string>((_, reject) =>
        setTimeout(() => reject(new Error('AI analysis timeout')), 8000)
      );
      record.aiSummary = await Promise.race([aiPromise, timeoutPromise]).catch(
        (err) => `AI Note: ${err.message || 'Sinusuri pa sa background'}`
      );
    } catch (e) {
      console.error('Auto AI analysis error:', e);
    }
  }

  const records = loadRecords();
  records[fileId] = record;
  saveRecords(records);

  return res.json({
    success: true,
    file: record,
    shareableLink: record.externalUrl || directShareUrl,
    directDownloadLink: record.externalUrl || directApiDownload,
    portalLink: directShareUrl,
    externalUrl: record.externalUrl,
  });
});

// Vite Middleware for Development / Static serving for production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Codetech Share server running on http://localhost:${PORT}`);
  });
}

startServer();
