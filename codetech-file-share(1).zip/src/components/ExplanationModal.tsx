import React from 'react';
import { X, CheckCircle2, ShieldAlert, Cpu, HardDrive, Zap, Info } from 'lucide-react';

interface ExplanationModalProps {
  onClose: () => void;
}

export const ExplanationModal: React.FC<ExplanationModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-cyan-500/40 rounded-2xl p-6 max-w-xl w-full shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
            <Zap className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Paano Pinalaki at Tinanggal ang Limit?</h2>
            <p className="text-xs text-cyan-400 font-mono">Codetech Architecture &amp; Gemini AI Integration</p>
          </div>
        </div>

        <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
          {/* Section 1 */}
          <div className="p-3.5 rounded-xl bg-red-950/20 border border-red-500/30">
            <div className="flex items-center gap-2 text-red-400 font-semibold mb-1.5 text-sm">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              Bakit nag-e-error dati ang tmpfiles.org?
            </div>
            <p>
              Ang libreng pampublikong endpoint ng <code>tmpfiles.org</code> ay may napakahigpit na restriction:
              nag-e-error o nagha-hang ito kapag ang file ay lumagpas ng ~50MB hanggang 100MB, nag-e-expire ang files sa loob ng 60 minuto, at madalas harangin ng CORS o server rate limits.
            </p>
          </div>

          {/* Section 2 */}
          <div className="p-3.5 rounded-xl bg-emerald-950/20 border border-emerald-500/30">
            <div className="flex items-center gap-2 text-emerald-400 font-semibold mb-1.5 text-sm">
              <HardDrive className="w-4 h-4 shrink-0" />
              Paano natin ginawang High-Capacity &amp; Walang Harang?
            </div>
            <ul className="space-y-2 list-disc list-inside">
              <li>
                <strong className="text-white">Codetech Dedicated Server Engine:</strong> Direktang nag-i-stream ang file sa ating backend server gamit ang chunked disk streaming. Walang 3rd-party error, mabilis, at may sariling direct shareable download link.
              </li>
              <li>
                <strong className="text-white">Multi-Gigabyte Support:</strong> Kayang tumanggap ng malalaking files (Videos, ISOs, ZIP, RAR, APK, Documents) na umaabot sa gigabytes nang hindi nagku-crash ang browser.
              </li>
              <li>
                <strong className="text-white">External Engine Fallbacks:</strong> May option din para sa GoFile (unlimited size API) o Litterbox (1GB) kung nais mong i-host sa external cloud.
              </li>
            </ul>
          </div>

          {/* Section 3 */}
          <div className="p-3.5 rounded-xl bg-cyan-950/20 border border-cyan-500/30">
            <div className="flex items-center gap-2 text-cyan-400 font-semibold mb-1.5 text-sm">
              <Cpu className="w-4 h-4 shrink-0" />
              Ano ang ginagawa ng ibinigay mong API Key?
            </div>
            <p className="mb-2">
              Ang ibinigay mong key (<code className="text-cyan-300">AQ.Ab8RN6IH...</code>) ay isang <strong className="text-white">Google Gemini AI API Key</strong>.
            </p>
            <p>
              Dahil ang Gemini ay isang makapangyarihang AI model at hindi lamang ordinaryong hard drive, isinama natin ito bilang <strong className="text-white">Smart File Intelligence Engine</strong>:
            </p>
            <div className="mt-2 pl-2 border-l-2 border-cyan-500/50 space-y-1">
              <div>✨ <span className="text-white font-medium">Auto-Summary:</span> Binabasa at ibinubuod ang laman ng mga PDF, text, at mga dokumento.</div>
              <div>✨ <span className="text-white font-medium">Media &amp; Code Inspector:</span> Sinusuri ang mga script, litrato, at content ng file.</div>
              <div>✨ <span className="text-white font-medium">Safety &amp; Instructions:</span> Nagbibigay ng maikling gabay sa tatanggap ng link kung paano ito bubuksan.</div>
            </div>
          </div>
        </div>

        <div className="mt-5 text-right">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition shadow-lg shadow-cyan-600/30"
          >
            Naiintindihan ko, Simulan na!
          </button>
        </div>
      </div>
    </div>
  );
};
