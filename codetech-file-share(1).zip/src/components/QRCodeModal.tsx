import React, { useState } from 'react';
import { X, Copy, Check, QrCode, ExternalLink } from 'lucide-react';

interface QRCodeModalProps {
  url: string;
  filename: string;
  onClose: () => void;
}

export const QRCodeModal: React.FC<QRCodeModalProps> = ({ url, filename, onClose }) => {
  const [copied, setCopied] = useState(false);

  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(url)}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-cyan-500/40 rounded-xl p-6 max-w-sm w-full shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-3.5 right-3.5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center">
          <div className="inline-flex p-2.5 rounded-full bg-cyan-500/10 text-cyan-400 mb-3 border border-cyan-500/30">
            <QrCode className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-white mb-1">I-scan Gamit ang Mobile</h3>
          <p className="text-xs text-slate-400 mb-4 truncate px-2" title={filename}>
            {filename}
          </p>

          <div className="bg-white p-3 rounded-lg inline-block shadow-inner mb-4">
            <img
              src={qrImageUrl}
              alt="QR Code"
              className="w-48 h-48 block"
              referrerPolicy="no-referrer"
            />
          </div>

          <p className="text-xs text-slate-400 mb-4 leading-relaxed">
            I-tutok ang camera ng iyong telepono upang agad mabuksan at ma-download ang file.
          </p>

          <div className="flex gap-2">
            <button
              onClick={handleCopy}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Na-kopya na!' : 'Kopyahin ang Link'}
            </button>
            <a
              href={url}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white transition"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Buksan
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
