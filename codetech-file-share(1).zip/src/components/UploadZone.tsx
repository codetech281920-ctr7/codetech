import React, { useRef, useState } from 'react';
import {
  UploadCloud,
  File,
  Sparkles,
  Server,
  Cloud,
  HardDrive,
  Info,
  CheckCircle,
  AlertTriangle,
  ChevronDown,
} from 'lucide-react';
import { StorageEngine, EngineOption } from '../types';
import { formatBytes, getFileCategory } from '../utils';

interface UploadZoneProps {
  selectedFile: File | null;
  onSelectFile: (file: File | null) => void;
  onUpload: (engine: StorageEngine, runAi: boolean) => void;
  isUploading: boolean;
  uploadProgress: number;
  uploadSpeed: string;
  onOpenExplanation: () => void;
}

const ENGINE_OPTIONS: EngineOption[] = [
  {
    id: 'codetech_server',
    name: 'Codetech Dedicated Cloud Server',
    badge: 'Inirerekomenda • Pinakamabilis',
    limitDesc: 'Walang 3rd-party error (Hanggang 5GB+ bawat file)',
    speed: 'High-speed instant streaming',
    description: 'Direktang naka-host sa ating dedicated container storage na may permanenteng link at video/media preview.',
  },
  {
    id: 'gofile',
    name: 'GoFile Unlimited Engine',
    badge: 'Multi-Gigabyte',
    limitDesc: 'Walang limit sa laki ng file (Libre)',
    speed: 'Mabilis sa malalaking archive at ISO',
    description: 'External cloud storage relay na walang restriction sa sukat ng file.',
  },
  {
    id: 'litterbox',
    name: 'Litterbox / Catbox Storage',
    badge: '1GB Limit',
    limitDesc: 'Hanggang 1GB bawat file',
    speed: 'Matatag na pampublikong download',
    description: 'Maasahang temporary file hosting.',
  },
  {
    id: 'tmpfiles',
    name: 'TmpFiles Engine (Legacy)',
    badge: '50MB - 100MB Limit',
    limitDesc: 'Limitado sa maliit na files lamang',
    speed: 'Mabilis mag-timeout sa malalaking files',
    description: 'Ang dating API na madalas mag-error sa malalaking MB.',
  },
];

export const UploadZone: React.FC<UploadZoneProps> = ({
  selectedFile,
  onSelectFile,
  onUpload,
  isUploading,
  uploadProgress,
  uploadSpeed,
  onOpenExplanation,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [selectedEngine, setSelectedEngine] = useState<StorageEngine>('codetech_server');
  const [runAi, setRunAi] = useState(true);
  const [showEngineDropdown, setShowEngineDropdown] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onSelectFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onSelectFile(e.target.files[0]);
    }
  };

  const currentEngine = ENGINE_OPTIONS.find((opt) => opt.id === selectedEngine) || ENGINE_OPTIONS[0];

  return (
    <div className="w-full rounded-2xl border border-slate-700/80 bg-slate-900/85 backdrop-blur-xl p-6 shadow-2xl relative text-slate-100">
      {/* Header Info Note */}
      <div className="flex items-start justify-between p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 mb-5">
        <div className="flex items-start space-x-2.5">
          <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div className="text-xs leading-relaxed text-slate-300">
            <span className="font-semibold text-cyan-300">Status ng Sistema: </span>
            Aktibo ang <strong className="text-white">High-Capacity Stream Engine</strong>. Inalis na ang dating 50MB restriction ng tmpfiles.org.
          </div>
        </div>
        <button
          onClick={onOpenExplanation}
          className="text-[11px] text-cyan-400 hover:text-cyan-200 underline font-medium whitespace-nowrap ml-2"
        >
          Paano ito gumagana?
        </button>
      </div>

      {/* Drag and Drop Zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all duration-300 ${
          isDragOver
            ? 'border-cyan-400 bg-cyan-500/10 scale-[1.01]'
            : 'border-slate-700 hover:border-cyan-500/60 hover:bg-slate-800/40'
        } ${isUploading ? 'pointer-events-none opacity-60' : ''}`}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          disabled={isUploading}
        />

        {selectedFile ? (
          <div className="flex flex-col items-center justify-center space-y-2 animate-fade-in">
            <div className="p-3.5 rounded-2xl bg-cyan-500/20 text-cyan-300 border border-cyan-400/40">
              <File className="w-8 h-8 animate-bounce" />
            </div>
            <p className="text-sm font-bold text-white max-w-sm truncate">
              {selectedFile.name}
            </p>
            <div className="flex items-center space-x-2 text-xs text-cyan-400 font-mono">
              <span>{formatBytes(selectedFile.size)}</span>
              <span>•</span>
              <span className="uppercase">{selectedFile.name.split('.').pop() || 'FILE'}</span>
              <span>•</span>
              <span className="text-emerald-400">Handa nang i-upload</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              I-click muli kung nais palitan ang napiling file.
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center space-y-3">
            <div className="p-3.5 rounded-2xl bg-slate-800 text-cyan-400 border border-slate-700 shadow-inner">
              <UploadCloud className="w-8 h-8" />
            </div>
            <div>
              <p className="text-sm font-semibold text-white">
                I-drag at i-drop ang iyong file dito, o <span className="text-cyan-400 underline">mag-browse</span>
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Tumatanggap ng Videos (MP4, MKV), Zip, RAR, APK, PDF, ISO, Musika, at kahit anong dokumento
              </p>
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800 text-[11px] text-slate-300 font-mono">
              <HardDrive className="w-3 h-3 text-emerald-400" />
              Kapasidad: Gigabytes ang kayang tanggapin
            </div>
          </div>
        )}
      </div>

      {/* Options Row: Storage Engine Selector + Gemini AI Toggle */}
      <div className="mt-5 space-y-4">
        {/* Engine Selection Accordion/Dropdown */}
        <div className="relative">
          <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-cyan-400" />
              Piliin ang Storage Engine:
            </span>
            <span className="text-[11px] text-emerald-400 font-mono font-medium">
              {currentEngine.badge}
            </span>
          </label>

          <button
            type="button"
            onClick={() => setShowEngineDropdown(!showEngineDropdown)}
            disabled={isUploading}
            className="w-full flex items-center justify-between p-3 rounded-xl border border-slate-700 bg-slate-950/70 hover:border-cyan-500/50 transition text-left"
          >
            <div>
              <div className="text-xs font-semibold text-white flex items-center gap-2">
                {currentEngine.name}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {currentEngine.limitDesc} • {currentEngine.speed}
              </p>
            </div>
            <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${showEngineDropdown ? 'rotate-180' : ''}`} />
          </button>

          {showEngineDropdown && (
            <div className="absolute z-20 mt-1.5 w-full rounded-xl border border-slate-700 bg-slate-900 shadow-2xl p-2 space-y-1 animate-fade-in">
              {ENGINE_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => {
                    setSelectedEngine(opt.id);
                    setShowEngineDropdown(false);
                  }}
                  className={`w-full text-left p-2.5 rounded-lg text-xs transition flex items-start justify-between ${
                    selectedEngine === opt.id
                      ? 'bg-cyan-500/15 border border-cyan-500/40 text-white'
                      : 'hover:bg-slate-800 text-slate-300'
                  }`}
                >
                  <div>
                    <div className="font-semibold flex items-center gap-2">
                      {opt.name}
                      {opt.id === 'codetech_server' && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-mono">
                          RECOMMENDED
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">{opt.description}</p>
                    <p className="text-[10px] text-cyan-400 font-mono mt-0.5">Kapasidad: {opt.limitDesc}</p>
                  </div>
                  {selectedEngine === opt.id && (
                    <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5 ml-2" />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Gemini AI Smart File Analyzer Toggle */}
        <div className="flex items-center justify-between p-3.5 rounded-xl border border-cyan-500/30 bg-cyan-950/20">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-cyan-500/20 text-cyan-300">
              <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
            </div>
            <div>
              <p className="text-xs font-semibold text-white">
                Suriin gamit ang Gemini 3.8 Flash AI
              </p>
              <p className="text-[11px] text-slate-400">
                Awtomatikong magbibigay ng buod at impormasyon sa file gamit ang ibinigay mong API key.
              </p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={runAi}
              onChange={(e) => setRunAi(e.target.checked)}
              disabled={isUploading}
              className="sr-only peer"
            />
            <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-500"></div>
          </label>
        </div>
      </div>

      {/* Upload Progress Bar */}
      {isUploading && (
        <div className="mt-5 p-4 rounded-xl bg-slate-950/80 border border-cyan-500/30 animate-fade-in">
          <div className="flex justify-between items-center text-xs mb-1.5 font-mono">
            <span className="text-cyan-300 font-semibold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              Nag-u-upload sa server...
            </span>
            <span className="text-white font-bold">{uploadProgress}%</span>
          </div>
          <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 via-sky-400 to-emerald-400 transition-all duration-200"
              style={{ width: `${uploadProgress}%` }}
            />
          </div>
          <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono mt-2">
            <span>Bilis: {uploadSpeed || 'Kinakalkula...'}</span>
            <span>Walang artificial timeout o rate limit</span>
          </div>
        </div>
      )}

      {/* Primary Action Button */}
      <button
        onClick={() => onUpload(selectedEngine, runAi)}
        disabled={!selectedFile || isUploading}
        className={`w-full mt-6 py-3.5 px-6 rounded-xl font-bold text-sm tracking-wide transition-all duration-300 flex items-center justify-center space-x-2 shadow-lg ${
          !selectedFile || isUploading
            ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
            : 'bg-gradient-to-r from-cyan-600 via-sky-600 to-blue-600 hover:from-cyan-500 hover:via-sky-500 hover:to-blue-500 text-white shadow-cyan-500/30 hover:shadow-cyan-500/50 hover:scale-[1.01]'
        }`}
      >
        {isUploading ? (
          <>
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
            <span>Ipinapadala ang File sa Server...</span>
          </>
        ) : (
          <>
            <Cloud className="w-4 h-4 mr-1" />
            <span>I-upload at Kunin ang Sharable Link</span>
          </>
        )}
      </button>
    </div>
  );
};
