import React, { useState } from 'react';
import { History, Copy, Check, Trash2, ExternalLink, HardDrive } from 'lucide-react';
import { FileRecord } from '../types';
import { formatBytes, formatDate } from '../utils';

interface RecentUploadsProps {
  files: FileRecord[];
  onDeleteFile: (id: string) => void;
  onOpenFile?: (id: string) => void;
  baseUrl: string;
}

export const RecentUploads: React.FC<RecentUploadsProps> = ({ files, onDeleteFile, onOpenFile, baseUrl }) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (files.length === 0) return null;

  const handleCopy = (file: FileRecord) => {
    const link = file.externalUrl || `${baseUrl}/download/${file.id}`;
    navigator.clipboard.writeText(link);
    setCopiedId(file.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="w-full mt-8 rounded-2xl border border-slate-800 bg-slate-900/70 backdrop-blur-md p-5 text-slate-100 shadow-xl">
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-800">
        <div className="flex items-center space-x-2">
          <History className="w-4 h-4 text-cyan-400" />
          <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
            Mga Na-upload Kamakailan ({files.length})
          </h3>
        </div>
        <span className="text-[11px] text-slate-400 font-mono">Naka-save sa server</span>
      </div>

      <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
        {files.map((file) => (
          <div
            key={file.id}
            className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:border-slate-700 transition"
          >
            <div className="overflow-hidden mr-2">
              <p className="text-xs font-semibold text-white truncate" title={file.originalName}>
                {file.originalName}
              </p>
              <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono mt-0.5">
                <span>{formatBytes(file.size)}</span>
                <span>•</span>
                <span>{formatDate(file.uploadDate)}</span>
                <span>•</span>
                <span className="text-cyan-400">{file.downloadCount || 0} downloads</span>
              </div>
            </div>

            <div className="flex items-center space-x-1.5 shrink-0">
              <button
                onClick={() => handleCopy(file)}
                title="Kopyahin ang Sharable Link"
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 transition text-xs flex items-center gap-1"
              >
                {copiedId === file.id ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>

              {onOpenFile ? (
                <button
                  onClick={() => onOpenFile(file.id)}
                  title="Buksan ang Link sa App"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 hover:text-white transition"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </button>
              ) : (
                <a
                  href={file.externalUrl || `${baseUrl}/download/${file.id}`}
                  target="_blank"
                  rel="noreferrer"
                  title="Buksan ang Link"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}

              <button
                onClick={() => onDeleteFile(file.id)}
                title="Burahin ang File"
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-red-950/60 text-slate-400 hover:text-red-400 transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
