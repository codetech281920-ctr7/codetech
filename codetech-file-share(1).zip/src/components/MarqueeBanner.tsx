import React from 'react';
import { Sparkles, ShieldCheck, Zap } from 'lucide-react';

export const MarqueeBanner: React.FC = () => {
  return (
    <div className="w-full max-w-3xl overflow-hidden rounded-lg border border-cyan-500/30 bg-cyan-950/20 backdrop-blur-sm mb-6 p-2.5 shadow-[0_0_15px_rgba(6,182,212,0.15)]">
      <div className="flex items-center space-x-3 whitespace-nowrap overflow-hidden">
        <span className="flex items-center gap-1.5 text-xs font-mono font-bold tracking-wider px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 uppercase shrink-0">
          <Zap className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
          CODETECH v2.0
        </span>

        <div className="relative flex overflow-x-hidden w-full">
          <div className="animate-marquee whitespace-nowrap flex gap-8 items-center text-xs font-mono font-semibold tracking-widest text-cyan-400">
            <span className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
              HIGH CAPACITY STORAGE • UNLIMITED FILE SHARING PORTAL
            </span>
            <span>•</span>
            <span className="flex items-center gap-2 text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              DIRECT SHARABLE LINKS
            </span>
            <span>•</span>
            <span className="text-sky-300">
              POWERED BY DEDICATED STREAM ENGINE &amp; GEMINI 3.8 FLASH
            </span>
            <span>•</span>
            <span className="flex items-center gap-2 text-yellow-300">
              WALANG 50MB TMPFILES TIMEOUT RESTRICTION
            </span>
            <span>•</span>
          </div>

          <div className="absolute top-0 animate-marquee2 whitespace-nowrap flex gap-8 items-center text-xs font-mono font-semibold tracking-widest text-cyan-400">
            <span className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
              HIGH CAPACITY STORAGE • UNLIMITED FILE SHARING PORTAL
            </span>
            <span>•</span>
            <span className="flex items-center gap-2 text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              DIRECT SHARABLE LINKS
            </span>
            <span>•</span>
            <span className="text-sky-300">
              POWERED BY DEDICATED STREAM ENGINE &amp; GEMINI 3.8 FLASH
            </span>
            <span>•</span>
            <span className="flex items-center gap-2 text-yellow-300">
              WALANG 50MB TMPFILES TIMEOUT RESTRICTION
            </span>
            <span>•</span>
          </div>
        </div>
      </div>
    </div>
  );
};
