import React, { useEffect, useState } from 'react';
import {
  Download,
  FileText,
  FileCode,
  FileArchive,
  Image as ImageIcon,
  Video,
  Music,
  File,
  ShieldCheck,
  Calendar,
  HardDrive,
  Sparkles,
  ArrowLeft,
  ExternalLink,
  Share2,
  Check,
} from 'lucide-react';
import { FileRecord } from '../types';
import { formatBytes, formatDate, getFileCategory } from '../utils';

interface DownloadViewProps {
  fileId: string;
  onGoHome: () => void;
}

export const DownloadView: React.FC<DownloadViewProps> = ({ fileId, onGoHome }) => {
  const [file, setFile] = useState<FileRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    async function fetchMeta() {
      try {
        setLoading(true);
        const res = await fetch(`/api/files/${fileId}/meta`);
        if (!res.ok) {
          throw new Error('Hindi nahanap ang file o maaaring tinanggal na.');
        }
        const data = await res.json();
        if (data.success && data.file) {
          setFile(data.file);
        } else {
          throw new Error(data.message || 'Nabigong kunin ang impormasyon ng file.');
        }
      } catch (err: any) {
        setError(err.message || 'Nagkaroon ng error sa pag-load ng file.');
      } finally {
        setLoading(false);
      }
    }
    fetchMeta();
  }, [fileId]);

  const [downloading, setDownloading] = useState(false);

  const handleCopy = () => {
    const textToCopy = file?.externalUrl || window.location.href;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTriggerDownload = async () => {
    if (!file) return;
    try {
      setDownloading(true);
      if (file.externalUrl) {
        window.open(file.externalUrl, '_blank');
        return;
      }

      const res = await fetch(`/api/download/${file.id}`);
      if (!res.ok) throw new Error('Download failed');
      const blob = await res.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const tempLink = document.createElement('a');
      tempLink.href = blobUrl;
      tempLink.download = file.originalName;
      document.body.appendChild(tempLink);
      tempLink.click();
      window.URL.revokeObjectURL(blobUrl);
      document.body.removeChild(tempLink);
    } catch (e) {
      console.warn('Fallback direct navigation:', e);
      window.location.href = `/api/download/${file.id}`;
    } finally {
      setTimeout(() => setDownloading(false), 2000);
    }
  };

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center space-y-4 text-center">
        <div className="w-12 h-12 border-4 border-cyan-400 border-t-transparent rounded-full animate-spin" />
        <p className="text-sm font-mono text-cyan-300">Kinukuha ang impormasyon ng file...</p>
      </div>
    );
  }

  if (error || !file) {
    return (
      <div className="max-w-md w-full mx-auto p-8 rounded-2xl bg-slate-900/90 border border-red-500/40 text-center shadow-2xl">
        <div className="w-12 h-12 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center mx-auto mb-4">
          <File className="w-6 h-6" />
        </div>
        <h2 className="text-lg font-bold text-white mb-2">Hindi Matagpuan ang File</h2>
        <p className="text-xs text-slate-400 mb-6">{error || 'Maaaring tinanggal na ang file o maling link ang binuksan.'}</p>
        <button
          onClick={onGoHome}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-semibold border border-slate-700 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          Bumalik sa Home
        </button>
      </div>
    );
  }

  const category = getFileCategory(file.mimeType, file.originalName);
  const downloadUrl = `/api/download/${file.id}`;
  const previewUrl = `/api/files/${file.id}/preview`;

  return (
    <div className="max-w-xl w-full mx-auto p-6 md:p-8 rounded-2xl bg-slate-900/90 border border-cyan-500/40 shadow-2xl backdrop-blur-xl animate-fade-in text-slate-100">
      {/* Top action */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
        <button
          onClick={onGoHome}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-cyan-300 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          Mag-upload ng Iba
        </button>

        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-xs text-cyan-300 hover:text-white bg-slate-800/80 px-2.5 py-1.5 rounded-lg border border-slate-700 transition"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
          {copied ? 'Na-kopya na!' : 'Ibahagi'}
        </button>
      </div>

      {/* File Card Header */}
      <div className="text-center mb-6">
        <div className="w-16 h-16 rounded-2xl bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 flex items-center justify-center mx-auto mb-3 shadow-[0_0_20px_rgba(6,182,212,0.2)]">
          {category === 'image' && <ImageIcon className="w-8 h-8 text-emerald-400" />}
          {category === 'video' && <Video className="w-8 h-8 text-purple-400" />}
          {category === 'audio' && <Music className="w-8 h-8 text-pink-400" />}
          {category === 'document' && <FileText className="w-8 h-8 text-blue-400" />}
          {category === 'archive' && <FileArchive className="w-8 h-8 text-amber-400" />}
          {category === 'code' && <FileCode className="w-8 h-8 text-cyan-400" />}
          {category === 'other' && <File className="w-8 h-8 text-slate-400" />}
        </div>

        <h1 className="text-xl font-bold text-white break-all mb-1 px-4" title={file.originalName}>
          {file.originalName}
        </h1>

        <div className="flex items-center justify-center gap-3 text-xs text-slate-400 font-mono mt-2 flex-wrap">
          <span className="flex items-center gap-1">
            <HardDrive className="w-3.5 h-3.5 text-cyan-400" />
            {formatBytes(file.size)}
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            {formatDate(file.uploadDate)}
          </span>
        </div>
      </div>

      {/* Inline Media Preview if applicable */}
      {category === 'image' && (
        <div className="mb-6 rounded-xl overflow-hidden border border-slate-800 bg-slate-950 p-2 text-center">
          <img
            src={previewUrl}
            alt={file.originalName}
            className="max-h-72 mx-auto rounded-lg object-contain"
            referrerPolicy="no-referrer"
          />
        </div>
      )}

      {category === 'video' && (
        <div className="mb-6 rounded-xl overflow-hidden border border-slate-800 bg-black">
          <video src={previewUrl} controls className="w-full max-h-72 rounded-lg" />
        </div>
      )}

      {category === 'audio' && (
        <div className="mb-6 p-4 rounded-xl border border-slate-800 bg-slate-950 text-center">
          <audio src={previewUrl} controls className="w-full" />
        </div>
      )}

      {/* Primary Download Button */}
      <button
        onClick={handleTriggerDownload}
        disabled={downloading}
        className="w-full py-4 px-6 rounded-xl font-bold text-base bg-gradient-to-r from-cyan-600 via-sky-600 to-blue-600 hover:from-cyan-500 hover:via-sky-500 hover:to-blue-500 text-white flex items-center justify-center gap-2 transition shadow-xl shadow-cyan-600/30 hover:shadow-cyan-600/50 hover:scale-[1.01] mb-3 text-center disabled:opacity-75"
      >
        <Download className="w-5 h-5" />
        {downloading ? 'Nagsisimula ang Pag-download...' : `I-download ang File (${formatBytes(file.size)})`}
      </button>

      {file.externalUrl && (
        <a
          href={file.externalUrl}
          target="_blank"
          rel="noreferrer"
          className="w-full py-2.5 px-4 rounded-xl font-medium text-xs bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-700 flex items-center justify-center gap-2 transition mb-5 text-center"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          Pampublikong Direct CDN Link (Kahit saang browser/device)
        </a>
      )}

      {/* Trust & Verification Badge */}
      <div className="flex items-center justify-center gap-2 p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-500/30 text-emerald-400 text-xs font-medium mb-6">
        <ShieldCheck className="w-4 h-4 shrink-0" />
        Direct download mula sa Codetech High-Capacity Storage Server. Walang mapanlinlang na pop-ups o ads.
      </div>

      {/* Gemini AI Summary Card if present */}
      {file.aiSummary && (
        <div className="p-4 rounded-xl bg-slate-950/80 border border-cyan-500/30 mb-6">
          <div className="flex items-center gap-2 text-xs font-bold text-cyan-300 uppercase tracking-wider mb-2 font-mono">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            Gemini AI Overview
          </div>
          <div className="text-xs text-slate-300 leading-relaxed whitespace-pre-line font-sans">
            {file.aiSummary}
          </div>
        </div>
      )}

      {/* Footer call to action */}
      <div className="text-center pt-4 border-t border-slate-800">
        <p className="text-xs text-slate-400 mb-2">Gusto mo ring mag-share ng malalaking files?</p>
        <button
          onClick={onGoHome}
          className="text-xs text-cyan-400 hover:text-cyan-300 underline font-medium"
        >
          Gumawa ng Sariling Sharable Link Dito
        </button>
      </div>
    </div>
  );
};
