import React, { useState } from 'react';
import {
  Check,
  Copy,
  Download,
  ExternalLink,
  QrCode,
  Sparkles,
  FileText,
  FileCode,
  FileArchive,
  Image as ImageIcon,
  Video,
  Music,
  File,
  RotateCcw,
  CheckCircle2,
} from 'lucide-react';
import { FileRecord } from '../types';
import { formatBytes, formatDate, getFileCategory } from '../utils';

interface ResultCardProps {
  file: FileRecord;
  shareableLink: string;
  directDownloadLink: string;
  portalLink?: string;
  onNavigateToPortal?: () => void;
  onUploadAnother: () => void;
  onOpenQR: () => void;
  onTriggerAI: () => void;
  isAiLoading: boolean;
}

export const ResultCard: React.FC<ResultCardProps> = ({
  file,
  shareableLink,
  directDownloadLink,
  portalLink,
  onNavigateToPortal,
  onUploadAnother,
  onOpenQR,
  onTriggerAI,
  isAiLoading,
}) => {
  const [copiedShare, setCopiedShare] = useState(false);
  const [copiedDirect, setCopiedDirect] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleCopyShare = () => {
    navigator.clipboard.writeText(shareableLink);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2200);
  };

  const handleCopyDirect = () => {
    navigator.clipboard.writeText(directDownloadLink);
    setCopiedDirect(true);
    setTimeout(() => setCopiedDirect(false), 2200);
  };

  // Direct download handler that works reliably even inside sandboxed iframes
  const handleTriggerDownload = async () => {
    try {
      setIsDownloading(true);
      if (file.externalUrl) {
        window.open(file.externalUrl, '_blank');
        return;
      }

      // Download from local server via blob stream
      const res = await fetch(`/api/download/${file.id}`);
      if (!res.ok) throw new Error('Download request failed');
      const blob = await res.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const tempLink = document.createElement('a');
      tempLink.href = blobUrl;
      tempLink.download = file.originalName;
      document.body.appendChild(tempLink);
      tempLink.click();
      window.URL.revokeObjectURL(blobUrl);
      document.body.removeChild(tempLink);
    } catch (e) {
      console.warn('Fallback direct navigation:', e);
      window.location.href = `/api/download/${file.id}`;
    } finally {
      setTimeout(() => setIsDownloading(false), 2000);
    }
  };

  const category = getFileCategory(file.mimeType, file.originalName);

  const getCategoryIcon = () => {
    switch (category) {
      case 'image':
        return <ImageIcon className="w-5 h-5 text-emerald-400" />;
      case 'video':
        return <Video className="w-5 h-5 text-purple-400" />;
      case 'audio':
        return <Music className="w-5 h-5 text-pink-400" />;
      case 'document':
        return <FileText className="w-5 h-5 text-blue-400" />;
      case 'archive':
        return <FileArchive className="w-5 h-5 text-amber-400" />;
      case 'code':
        return <FileCode className="w-5 h-5 text-cyan-400" />;
      default:
        return <File className="w-5 h-5 text-slate-400" />;
    }
  };

  return (
    <div className="w-full mt-6 rounded-2xl border border-emerald-500/40 bg-slate-900/90 backdrop-blur-md p-6 shadow-[0_10px_30px_rgba(16,185,129,0.15)] animate-fade-in text-slate-100">
      {/* Top Banner */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-white text-base">Tagumpay ang Pag-upload!</h3>
            <p className="text-xs text-emerald-400 font-mono">Handa na ang iyong high-capacity sharable link.</p>
          </div>
        </div>

        <button
          onClick={onUploadAnother}
          className="flex items-center gap-1 text-xs text-slate-400 hover:text-white px-2.5 py-1.5 rounded-lg hover:bg-slate-800 transition border border-slate-800"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Upload Pa
        </button>
      </div>

      {/* File Info Meta Pill */}
      <div className="flex items-center justify-between my-4 p-3 rounded-xl bg-slate-950/70 border border-slate-800">
        <div className="flex items-center space-x-3 overflow-hidden mr-3">
          <div className="p-2 rounded-lg bg-slate-800/80 shrink-0">
            {getCategoryIcon()}
          </div>
          <div className="overflow-hidden">
            <p className="text-sm font-semibold text-white truncate" title={file.originalName}>
              {file.originalName}
            </p>
            <p className="text-xs text-slate-400 font-mono">
              {formatBytes(file.size)} • {file.mimeType || 'binary/octet-stream'}
            </p>
          </div>
        </div>

        <div className="shrink-0 text-right">
          <span className="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-mono font-medium bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
            {file.storageEngine === 'codetech_server' ? 'Codetech Cloud' : file.storageEngine}
          </span>
          <p className="text-[10px] text-slate-500 font-mono mt-0.5">{formatDate(file.uploadDate)}</p>
        </div>
      </div>

      {/* Primary Sharable Link Box */}
      <div className="space-y-3 mt-4">
        <div>
          <label className="block text-xs font-semibold text-cyan-300 mb-1.5 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              🌐 Pampublikong Sharable Link (Kahit kanino pwede i-send • Walang login)
            </span>
            <span className="text-[10px] text-emerald-400 font-normal">100% Gumagana sa Lahat</span>
          </label>
          <div className="flex rounded-xl overflow-hidden border border-cyan-500/50 bg-slate-950/90 focus-within:border-cyan-400 transition shadow-inner">
            <input
              type="text"
              readOnly
              value={shareableLink}
              className="w-full bg-transparent px-3 py-2.5 text-xs text-cyan-300 font-mono outline-none selection:bg-cyan-500/30"
            />
            <button
              onClick={handleCopyShare}
              className={`px-4 py-2 text-xs font-semibold flex items-center gap-1.5 transition shrink-0 ${
                copiedShare
                  ? 'bg-emerald-600 text-white'
                  : 'bg-cyan-600 hover:bg-cyan-500 text-white'
              }`}
            >
              {copiedShare ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedShare ? 'Na-kopya!' : 'Kopyahin'}
            </button>
          </div>
        </div>

        {/* Direct Download Stream Link */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
            <span>⚡ Direct Instant Download Stream</span>
            <span className="text-[10px] text-slate-400 font-normal">Direktang stream link</span>
          </label>
          <div className="flex rounded-xl overflow-hidden border border-slate-700 bg-slate-950/90 focus-within:border-cyan-500 transition">
            <input
              type="text"
              readOnly
              value={directDownloadLink}
              className="w-full bg-transparent px-3 py-2 text-xs text-slate-300 font-mono outline-none selection:bg-cyan-500/30"
            />
            <button
              onClick={handleCopyDirect}
              className={`px-3 py-2 text-xs font-semibold flex items-center gap-1.5 transition shrink-0 ${
                copiedDirect
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
              }`}
            >
              {copiedDirect ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedDirect ? 'Na-kopya!' : 'Kopyahin'}
            </button>
          </div>
        </div>
      </div>

      {/* Action Buttons Row */}
      <div className="grid grid-cols-3 gap-2.5 mt-5">
        <button
          onClick={handleTriggerDownload}
          disabled={isDownloading}
          className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-600 to-sky-600 hover:from-cyan-500 hover:to-sky-500 text-white font-semibold text-xs transition shadow-lg shadow-cyan-600/25 text-center disabled:opacity-60"
        >
          <Download className="w-3.5 h-3.5" />
          {isDownloading ? 'Nagsisimula...' : 'I-download Agad'}
        </button>

        <button
          onClick={onOpenQR}
          className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs transition text-center"
        >
          <QrCode className="w-3.5 h-3.5 text-cyan-400" />
          QR Para sa Mobile
        </button>

        {onNavigateToPortal ? (
          <button
            onClick={onNavigateToPortal}
            className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs transition text-center hover:text-cyan-300"
          >
            <ExternalLink className="w-3.5 h-3.5 text-sky-400" />
            Buksan ang Page
          </button>
        ) : (
          <a
            href={shareableLink}
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs transition text-center"
          >
            <ExternalLink className="w-3.5 h-3.5 text-sky-400" />
            Tingnan ang Page
          </a>
        )}
      </div>

      {/* Gemini AI Intelligence Section */}
      <div className="mt-6 pt-5 border-t border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
            <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              Gemini 3.8 Flash File Analysis
            </span>
          </div>

          {!file.aiSummary && (
            <button
              onClick={onTriggerAI}
              disabled={isAiLoading}
              className="text-xs text-cyan-300 hover:text-cyan-200 bg-cyan-950/60 border border-cyan-500/40 hover:bg-cyan-900/60 px-2.5 py-1 rounded-lg transition flex items-center gap-1.5 disabled:opacity-50"
            >
              <Sparkles className="w-3 h-3" />
              {isAiLoading ? 'Sinusuri ng AI...' : 'I-analyze gamit ang AI Key'}
            </button>
          )}
        </div>

        {file.aiSummary ? (
          <div className="p-4 rounded-xl bg-slate-950/80 border border-cyan-500/20 text-xs text-slate-300 leading-relaxed font-sans whitespace-pre-line">
            {file.aiSummary}
          </div>
        ) : isAiLoading ? (
          <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 text-center py-6">
            <div className="inline-block w-6 h-6 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mb-2" />
            <p className="text-xs text-cyan-300 font-mono">
              Sinasaliksik ng Gemini 3.8 Flash ang nilalaman ng iyong file...
            </p>
          </div>
        ) : (
          <p className="text-[11px] text-slate-400 italic">
            I-click ang &quot;I-analyze gamit ang AI Key&quot; upang basahin at ibuod ng Gemini AI ang nilalaman ng file na ito.
          </p>
        )}
      </div>
    </div>
  );
};
