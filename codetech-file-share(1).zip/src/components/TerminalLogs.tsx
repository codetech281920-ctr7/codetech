import React, { useEffect, useRef } from 'react';
import { Terminal, Trash2, CheckCircle2, AlertCircle, Info, AlertTriangle } from 'lucide-react';
import { LogEntry } from '../types';

interface TerminalLogsProps {
  logs: LogEntry[];
  onClear: () => void;
  isStreaming?: boolean;
}

export const TerminalLogs: React.FC<TerminalLogsProps> = ({ logs, onClear, isStreaming }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [logs]);

  if (logs.length === 0) return null;

  return (
    <div className="w-full mt-4 rounded-lg overflow-hidden border border-slate-700/80 bg-slate-950/90 shadow-2xl font-mono text-xs">
      {/* Terminal Title Bar */}
      <div className="flex items-center justify-between px-3 py-2 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center space-x-2">
          <div className="flex space-x-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
          </div>
          <span className="text-[11px] text-slate-400 flex items-center gap-1.5 font-medium ml-2">
            <Terminal className="w-3 h-3 text-cyan-400" />
            codetech-process.log {isStreaming && <span className="inline-block w-1.5 h-3 bg-cyan-400 animate-pulse ml-1" />}
          </span>
        </div>
        <button
          onClick={onClear}
          title="Linisin ang log"
          className="text-slate-400 hover:text-slate-200 transition-colors p-1 rounded hover:bg-slate-800"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Log list */}
      <div
        ref={containerRef}
        className="p-3 max-h-48 overflow-y-auto space-y-1.5 font-mono text-[11px] select-text"
      >
        {logs.map((log) => {
          let Icon = Info;
          let textColor = 'text-cyan-300';

          if (log.type === 'success') {
            Icon = CheckCircle2;
            textColor = 'text-emerald-400';
          } else if (log.type === 'error') {
            Icon = AlertCircle;
            textColor = 'text-red-400';
          } else if (log.type === 'warning') {
            Icon = AlertTriangle;
            textColor = 'text-yellow-300';
          }

          return (
            <div key={log.id} className="flex items-start space-x-2 leading-relaxed">
              <span className="text-slate-500 text-[10px] shrink-0 mt-0.5">[{log.timestamp}]</span>
              <Icon className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${textColor}`} />
              <span className={`${textColor} break-all`}>{log.text}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
