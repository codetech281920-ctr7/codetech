export type StorageEngine = 'codetech_server' | 'gofile' | 'litterbox' | 'tmpfiles';

export interface FileRecord {
  id: string;
  originalName: string;
  filename: string;
  size: number;
  mimeType: string;
  uploadDate: string;
  storageEngine: StorageEngine;
  externalUrl?: string;
  downloadCount: number;
  aiSummary?: string;
}

export interface UploadResponse {
  success: boolean;
  file?: FileRecord;
  shareableLink?: string;
  directDownloadLink?: string;
  externalUrl?: string;
  message?: string;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  text: string;
  type: 'info' | 'success' | 'error' | 'warning';
}

export interface EngineOption {
  id: StorageEngine;
  name: string;
  badge: string;
  limitDesc: string;
  speed: string;
  description: string;
}
