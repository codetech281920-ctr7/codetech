import React, { useState, useEffect, useCallback } from 'react';
import {
  Zap,
  HelpCircle,
  FolderSync,
  Radio,
  Cpu,
} from 'lucide-react';
import { MarqueeBanner } from './components/MarqueeBanner';
import { UploadZone } from './components/UploadZone';
import { TerminalLogs } from './components/TerminalLogs';
import { ResultCard } from './components/ResultCard';
import { DownloadView } from './components/DownloadView';
import { RecentUploads } from './components/RecentUploads';
import { ExplanationModal } from './components/ExplanationModal';
import { QRCodeModal } from './components/QRCodeModal';
import { FileRecord, LogEntry, StorageEngine } from './types';
import { formatBytes } from './utils';

export default function App() {
  // Routing state
  const [currentRoute, setCurrentRoute] = useState<{ path: string; fileId?: string }>({
    path: window.location.pathname,
  });

  // Upload states
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadSpeed, setUploadSpeed] = useState('');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [uploadResult, setUploadResult] = useState<{
    file: FileRecord;
    shareableLink: string;
    directDownloadLink: string;
    portalLink?: string;
  } | null>(null);

  // History & modals
  const [recentFiles, setRecentFiles] = useState<FileRecord[]>([]);
  const [showExplanation, setShowExplanation] = useState(false);
  const [showQR, setShowQR] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Determine base host URL
  const baseUrl = window.location.origin;

  const navigateToDownload = (fileId: string) => {
    window.history.pushState({}, '', `/download/${fileId}`);
    setCurrentRoute({ path: 'download', fileId });
  };

  // Listen to path / hash changes for download links
  useEffect(() => {
    const handleLocationChange = () => {
      const pathname = window.location.pathname;
      const hash = window.location.hash;

      if (pathname.startsWith('/download/')) {
        const fileId = pathname.replace('/download/', '').split('/')[0];
        setCurrentRoute({ path: 'download', fileId });
      } else if (hash.startsWith('#download-')) {
        const fileId = hash.replace('#download-', '');
        setCurrentRoute({ path: 'download', fileId });
      } else {
        setCurrentRoute({ path: 'home' });
      }
    };

    handleLocationChange();
    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  // Fetch recent files from server
  const fetchRecentFiles = useCallback(async () => {
    try {
      const res = await fetch('/api/files/recent');
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.files) {
          setRecentFiles(data.files);
        }
      }
    } catch (e) {
      console.warn('Failed to load recent files:', e);
    }
  }, []);

  useEffect(() => {
    fetchRecentFiles();
  }, [fetchRecentFiles]);

  // Typewriter Log Helper
  const addLog = useCallback((text: string, type: 'info' | 'success' | 'error' | 'warning' = 'info') => {
    const now = new Date().toLocaleTimeString('en-GB', { hour12: false });
    const newEntry: LogEntry = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: now,
      text,
      type,
    };
    setLogs((prev) => [...prev, newEntry]);
  }, []);

  // Handle File Selection
  const handleSelectFile = (file: File | null) => {
    setSelectedFile(file);
    setUploadResult(null);
    if (file) {
      const sizeLabel = formatBytes(file.size);
      addLog(`Na-detect ang file: "${file.name}" (${sizeLabel})`, 'info');
      addLog('Inaalis ang lahat ng client-side size restrictions...', 'info');
      addLog('Kapasidad: Handa para sa high-capacity stream.', 'success');
    }
  };

  // Perform upload with streaming & real-time progress
  const handleUpload = (engine: StorageEngine, runAi: boolean) => {
    if (!selectedFile) return;

    setIsUploading(true);
    setUploadProgress(0);
    setUploadSpeed('');
    setUploadResult(null);

    const startTime = Date.now();
    let lastLoaded = 0;
    let lastTime = startTime;

    addLog(`Sinisimulan ang pag-stream gamit ang [${engine.toUpperCase()}] engine...`, 'info');
    if (runAi) {
      addLog('Gemini 3.8 Flash AI File Analyzer: NAKA-ON', 'info');
    }

    const formData = new FormData();
    formData.append('file', selectedFile);
    formData.append('engine', engine);
    formData.append('runAi', runAi ? 'true' : 'false');

    const xhr = new XMLHttpRequest();

    xhr.upload.addEventListener('progress', (e) => {
      if (e.lengthComputable) {
        const percent = Math.round((e.loaded / e.total) * 100);
        setUploadProgress(percent);

        const currentTime = Date.now();
        const timeDiff = (currentTime - lastTime) / 1000;
        if (timeDiff >= 0.3) {
          const loadedDiff = e.loaded - lastLoaded;
          const speedBytesPerSec = loadedDiff / timeDiff;
          setUploadSpeed(`${formatBytes(speedBytesPerSec)}/s`);
          lastLoaded = e.loaded;
          lastTime = currentTime;
        }
      }
    });

    xhr.addEventListener('load', () => {
      setIsUploading(false);
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const response = JSON.parse(xhr.responseText);
          if (response.success && response.file) {
            const publicShareLink = response.shareableLink || (response.file.externalUrl ? response.file.externalUrl : `${baseUrl}/download/${response.file.id}`);
            const directLink = response.directDownloadLink || (response.file.externalUrl ? response.file.externalUrl : `${baseUrl}/api/download/${response.file.id}`);
            const portalLink = response.portalLink || `${baseUrl}/download/${response.file.id}`;

            addLog(`Natanggap ang tugon mula sa server (Status: ${xhr.status})`, 'success');
            addLog('Tagumpay! Handa na ang 100% gumaganang sharable link.', 'success');
            if (response.file.aiSummary) {
              addLog('Nakumpleto ng Gemini 3.8 Flash ang pagsusuri sa nilalaman.', 'success');
            }

            setUploadResult({
              file: response.file,
              shareableLink: publicShareLink,
              directDownloadLink: directLink,
              portalLink: portalLink,
            });

            fetchRecentFiles();
          } else {
            throw new Error(response.message || 'Nabigo ang server na i-proseso ang file.');
          }
        } catch (err: any) {
          addLog(`Error sa pagbasa ng tugon: ${err.message}`, 'error');
        }
      } else {
        addLog(`Upload error (HTTP ${xhr.status}): Hindi tinanggap ng server.`, 'error');
      }
    });

    xhr.addEventListener('error', () => {
      setIsUploading(false);
      addLog('Network Error: Nabigo ang koneksyon sa server habang nag-stream.', 'error');
    });

    xhr.open('POST', '/api/upload');
    xhr.send(formData);
  };

  // Trigger AI Analysis manually
  const handleTriggerAI = async () => {
    if (!uploadResult) return;
    setIsAiLoading(true);
    addLog(`Pinapagana ang Gemini 3.8 Flash para sa "${uploadResult.file.originalName}"...`, 'info');

    try {
      const res = await fetch(`/api/analyze-ai/${uploadResult.file.id}`, {
        method: 'POST',
      });
      const data = await res.json();
      if (data.success && data.aiSummary) {
        setUploadResult((prev) =>
          prev
            ? {
                ...prev,
                file: {
                  ...prev.file,
                  aiSummary: data.aiSummary,
                },
              }
            : null
        );
        addLog('Matagumpay na natapos ng Gemini ang pagsusuri ng file!', 'success');
      } else {
        throw new Error(data.message || 'Nabigo ang AI analysis');
      }
    } catch (err: any) {
      addLog(`AI Error: ${err.message}`, 'error');
    } finally {
      setIsAiLoading(false);
    }
  };

  // Delete file handler with fallback and optimistic update
  const handleDeleteFile = async (id: string) => {
    // Optimistically update recent files list in UI immediately
    setRecentFiles((prev) => prev.filter((f) => f.id !== id));
    if (uploadResult?.file.id === id) {
      setUploadResult(null);
    }

    try {
      // Try standard DELETE request
      let res = await fetch(`/api/files/${id}`, {
        method: 'DELETE',
        headers: { 'Accept': 'application/json' },
      }).catch(() => null);

      // If DELETE failed or was blocked by browser/sandbox, fallback to POST /delete
      if (!res || !res.ok) {
        res = await fetch(`/api/files/${id}/delete`, {
          method: 'POST',
          headers: { 'Accept': 'application/json' },
        }).catch(() => null);
      }

      if (res && res.ok) {
        addLog(`Nabura ang file [${id}] mula sa server storage.`, 'warning');
      } else {
        addLog(`File [${id}] inalis sa aktibong listahan.`, 'info');
      }
      fetchRecentFiles();
    } catch (e: any) {
      console.warn('File delete notice:', e);
      addLog(`File [${id}] inalis sa session.`, 'warning');
    }
  };

  const navigateToHome = () => {
    window.history.pushState({}, '', '/');
    window.location.hash = '';
    setCurrentRoute({ path: 'home' });
  };

  // If viewing a shared download link
  if (currentRoute.path === 'download' && currentRoute.fileId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-slate-100 flex flex-col justify-center items-center p-4">
        <DownloadView fileId={currentRoute.fileId} onGoHome={navigateToHome} />
      </div>
    );
  }

  // Main Portal View
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0f1d] via-[#0f172a] to-[#14122c] text-slate-100 flex flex-col items-center justify-start py-8 px-4 sm:px-6 relative overflow-x-hidden selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Background cyber grid accents */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:3rem_3rem] pointer-events-none" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[40rem] h-[20rem] bg-cyan-500/10 blur-[130px] rounded-full pointer-events-none" />

      {/* Marquee Banner */}
      <MarqueeBanner />

      {/* Main Container Box */}
      <main className="w-full max-w-2xl relative z-10 space-y-6">
        {/* Header Branding */}
        <header className="flex flex-col sm:flex-row items-center justify-between pb-4 border-b border-slate-800 gap-4">
          <div className="flex items-center space-x-3 text-center sm:text-left">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/30 border border-cyan-400/40">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white font-mono">
                  CODETECH SHARE
                </h1>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 font-mono font-semibold">
                  NO-LIMIT
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Mag-upload at Kumuha ng Instant Sharable Download Link
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowExplanation(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-700/80 text-xs font-semibold transition"
            >
              <HelpCircle className="w-4 h-4 text-cyan-400" />
              Bakit Walang Limit?
            </button>
          </div>
        </header>

        {/* Upload Zone */}
        <UploadZone
          selectedFile={selectedFile}
          onSelectFile={handleSelectFile}
          onUpload={handleUpload}
          isUploading={isUploading}
          uploadProgress={uploadProgress}
          uploadSpeed={uploadSpeed}
          onOpenExplanation={() => setShowExplanation(true)}
        />

        {/* Live Terminal Log Stream */}
        <TerminalLogs
          logs={logs}
          onClear={() => setLogs([])}
          isStreaming={isUploading}
        />

        {/* Upload Result Output Card */}
        {uploadResult && (
          <ResultCard
            file={uploadResult.file}
            shareableLink={uploadResult.shareableLink}
            directDownloadLink={uploadResult.directDownloadLink}
            portalLink={uploadResult.portalLink}
            onNavigateToPortal={() => navigateToDownload(uploadResult.file.id)}
            onUploadAnother={() => {
              setSelectedFile(null);
              setUploadResult(null);
            }}
            onOpenQR={() => setShowQR(true)}
            onTriggerAI={handleTriggerAI}
            isAiLoading={isAiLoading}
          />
        )}

        {/* History / Recent Uploads */}
        <RecentUploads
          files={recentFiles}
          onDeleteFile={handleDeleteFile}
          onOpenFile={(id) => navigateToDownload(id)}
          baseUrl={baseUrl}
        />

        {/* Footer Info */}
        <footer className="text-center pt-8 pb-4 text-xs text-slate-500 space-y-1">
          <p>
            ⚡ Powered by Codetech Multi-Gigabyte Stream Engine • Gemini 3.8 Flash AI Model
          </p>
          <p className="text-[11px] text-slate-600">
            Ligtas at direktang pagbabahagi ng mga files nang walang mapanlinlang na pop-ups o timers.
          </p>
        </footer>
      </main>

      {/* Explanation Modal */}
      {showExplanation && (
        <ExplanationModal onClose={() => setShowExplanation(false)} />
      )}

      {/* QR Code Modal */}
      {showQR && uploadResult && (
        <QRCodeModal
          url={uploadResult.shareableLink}
          filename={uploadResult.file.originalName}
          onClose={() => setShowQR(false)}
        />
      )}
    </div>
  );
}
